"use strict"

module.exports = (context, callback) => {
    callback(undefined, {status: "done"});
}
