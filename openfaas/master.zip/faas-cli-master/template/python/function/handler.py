def handle(st):
    print(st)
